$(document).ready(() => {
  localStorage.removeItem('seu-credito-agora-step1')
})